/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banco;

/**
 *
 * @author eliag
 */
public class Reporte {

    private String numeroCuenta; // Número de cuenta del usuario
    private String descripcion;  // Descripción del reporte
    private int estado;         // 1 = Pendiente, 0 = Finalizado

    // Constructor
    public Reporte(String numeroCuenta, String descripcion, int estado) {
        this.numeroCuenta = numeroCuenta;
        this.descripcion = descripcion;
        this.estado = estado;
    }

    // Getters y Setters
    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    //Metodo para mostrar el reporte en formato legible
    @Override
    public String toString() {
        String estadoStr = (estado == 1) ? "Pendiente" : "Finalizado";
        return String.format(
                "Número de cuenta: %s | Descripción: %s | Estado: %s",
                numeroCuenta, descripcion, estadoStr
        );
    }
}
