/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banco;

/**
 *
 * @author eliag
 */
public class SolicitudInversion {
    private String numeroCuenta; // Número de cuenta del cliente
    private String cuenta1;  // Nombre o ID del que envía la solicitud
    private String cuenta2;  // Nombre o ID del que acepta la solicitud
    private int estado;         // 1 = Pendiente, 2 = Aprobada, 0 = Rechazada

    // Constructor
    public SolicitudInversion(String numeroCuenta, String cuenta1, String cuenta2, int estado) {
        this.numeroCuenta = numeroCuenta;
        this.cuenta1 = cuenta1;
        this.cuenta2 = cuenta2;
        this.estado = estado;
    }

    // Getters y Setters
    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public String getCuenta1() {
        return cuenta1;
    }

    public String getCuenta2() {
        return cuenta2;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public void setCuenta2(String cuenta2) {
        this.cuenta2 = cuenta2;
    }

    // Método para mostrar la solicitud en formato legible
    public String toString() {
        String estadoStr;
        switch (estado) {
            case 1:
                estadoStr = "Pendiente";
                break;
            case 2:
                estadoStr = "Aprobada";
                break;
            case 0:
                estadoStr = "Rechazada";
                break;
            default:
                estadoStr = "Desconocido";
        }
        return String.format(
                "Número de cuenta: %s | Cuenta Solicitante: %s | Revisado por: %s | Estado: %s",
                numeroCuenta, cuenta1, cuenta2, estadoStr
        );
    }
}
