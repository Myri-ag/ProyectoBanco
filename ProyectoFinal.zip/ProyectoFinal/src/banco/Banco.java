/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package banco;

    import java.time.LocalDate;
    import java.util.ArrayList;
    import java.util.List;
    import java.util.Scanner;
    import java.util.Random;


public class Banco {

    private Random random = new Random();

    private List<Cuenta> cuentas;
    private List<SubCuenta> subCuentas;
    private List<Usuario> usuarios;
    private List<Contacto> contactos;
    private List<SubGerente> subgerentes;
    private List<Ventanilla> cajeros;
    private List<Reporte> reportes;
    private List<SolicitudInversion> solicitudes;
    private String[] movimientos;
    private int cont_movimientos;
    private int[] contadores;
    private double saldoInicial;
    private Scanner scanner;
    private double saldoCajero;

    // Constructor
    public Banco(Scanner scanner) {
        this.cuentas = new ArrayList<>();
        this.subCuentas = new ArrayList<>();
        this.usuarios = new ArrayList<>();
        this.contactos = new ArrayList<>();
        this.subgerentes = new ArrayList<>();
        this.cajeros = new ArrayList<>();
        this.reportes = new ArrayList<>();
        this.solicitudes = new ArrayList<>();
        this.movimientos = new String[99];
        this.cont_movimientos = 1;
        this.contadores = new int[]{1, 1, 1, 1, 1, 1, 1}; //[0] cuentas, [1] usuarios, [2] contactos, [3] cajeros, [4] subgerentes, [5] subcuentas. [6] SaldoConIntereses
        this.scanner = scanner;
        this.saldoInicial = 20000000;
        this.saldoCajero = 2000000;
    }

    //---------------------------------------------------------------------------------------------------------

    //Validaciones

    //Metodo para validar la fecha
    public static String validarFecha() {
        // Instanciar un objeto de la clase Scanner para recibir datos
        Scanner scanner = new Scanner(System.in);
        String entrada;
        while (true) {
            entrada = scanner.nextLine();
            // Verificar si la fecha tiene el formato dd/mm/aaaa
            if (entrada.matches("^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/\\d{4}$")) {
                // Retornar la fecha si es válida
                return entrada;
            } else {
                System.out.println("Formato de fecha inválido! Ingresa la fecha en formato dd/mm/aaaa:");
            }
        }
    }

    //Metodo para confirmar la decisión del usuario
    public static String confirmar_Decision(){

        Scanner scanner = new Scanner(System.in);
        String decision;
        System.out.println("\n ¿Desea guardar los cambios realizados?  (1: si  , 2: no)");
        do{
            decision = scanner.nextLine();
        }while(!decision.equals("1") && !decision.equals("2"));
        return decision;
    }

    //Metodo para validar que solo se ingresen números
    private String validarSoloNumeros() {
        String input;
        while (true) {
            input = scanner.nextLine();
            if (input.matches("\\d+")) {
                return input;
            } else {
                System.out.println("Solo se permiten números! Intente de nuevo:");
            }
        }
    }

    //Metodo para validar que solo se ingresen numeros positivos
    public static int validarNumeroPositivo() {
        Scanner scanner = new Scanner(System.in);
        int numero;
        while (true) {
            if (scanner.hasNextInt() && (numero = scanner.nextInt()) > 0) {
                return numero;
            }
            System.out.println("Ingresa un número válido mayor a 0:");
            scanner.next(); // Limpiar el buffer del scanner
        }
    }

    //Metodo para validar que solo se ingresen letras
    public static String validarSoloLetras() {
        // Instanciar un objeto de la clase Scanner para recibir datos
        Scanner scanner = new Scanner(System.in);
        String entrada;
        while (true) {
            entrada = scanner.nextLine();
            // Verificar si la cadena contiene solo letras (incluyendo acentos y ñ)
            if (entrada.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑüÜ]+")) {
                // Retornar la cadena si es válida
                return entrada;
            } else {
                System.out.println("No es una entrada válida! Ingresa nuevamente:");
            }
        }
    }

    //Metodo para obtener la fecha actual
    public static LocalDate fechaActual() {
        // Obtener la fecha actual (sin hora)
        return LocalDate.now();
    }

    //---------------------------------------------------------------------------------------------------------

    //Administrador

    //Metodo para que un administrador vea todos los reportes
    public void verTodosLosReportes() {
        System.out.println(" ꒰◌; Listado de reportes ");

        if (reportes.isEmpty()) {
            System.out.println("No hay reportes registrados.");
        } else {
            for (Reporte reporte : reportes) {
                System.out.println(reporte);
            }
        }
    }

    //Metodo para que un administrador cambie el estado de un reporte
    public void cambiarEstadoReporte() {

        System.out.println(" ꒰◌; Cambiar estado de reporte ");
        System.out.print("\nIngrese el número de cuenta del reporte: ");
        String numeroCuenta = scanner.nextLine();

        boolean reporteEncontrado = false;
        for (Reporte reporte : reportes) {
            if (reporte.getNumeroCuenta().equals(numeroCuenta)) {
                System.out.println("Reporte encontrado: " + reporte);
                System.out.println("¿Desea marcarlo como finalizado? (1 = Sí, 0 = No): ");
                int opcion = scanner.nextInt();

                if (opcion == 1) {
                    reporte.setEstado(0); // Cambiar estado a "Finalizado"
                    System.out.println("Estado del reporte actualizado a Finalizado.");
                } else {
                    System.out.println("El estado del reporte no ha sido modificado.");
                }

                reporteEncontrado = true;
                break;
            }
        }

        if (!reporteEncontrado) {
            System.out.println("No se encontró ningún reporte con ese número de cuenta.");
        }
    }

    //---------------------------------------------------------------------------------------------------------

    //SubGerentes

    //Metodo para iniciar sesión
    public int SesionSubgerente() {
        System.out.println("\n \n ───────────");
        System.out.print("Ingrese el usuario: ");
        String usuario = scanner.nextLine();
        System.out.print("Ingrese la contraseña: ");
        String contrasenia = scanner.nextLine();

        for (SubGerente user : subgerentes) {
            if (user.getNombreUsuario().equals(usuario) && user.getContrasenia().equals(contrasenia)) {
                System.out.println("Inicio de sesión exitoso!");
                System.out.println(" ───────────");
                return Integer.parseInt(user.getIdSubgerente());
            }
        }

        System.out.println("Usuario y/o contraseña incorrectos ! ! !");
        System.out.println(" ───────────");
        return 0;
    }

    //Metodo para verificar si el gerente ya existe
    private boolean existeSubgerente(String nombreUsuario) {
        for (SubGerente user : subgerentes) {
            if (user.getNombreUsuario().equals(nombreUsuario)) {
                return true; //El gerente ya existe
            }
        }
        return false;
    }


    //Metodo para buscar el nombre del Gerente dado el ID
    public String buscarSubgerente(String id_subgerente){
        for (SubGerente user : subgerentes) {
            if (user.getIdSubgerente().equals(String.valueOf(id_subgerente))) {
                return user.getNombreUsuario();
            }
        }
        return "0";
    }

    //Metodo para crear gerente   YA NO SE USA
    public void agregarSubgerente(int id_usuario, int tipo_usuario) {

        String idSubgerente = String.valueOf(contadores[4]);  //el id del subgerente
        System.out.print("Ingrese el nombre completo: ");
        String nombre = scanner.nextLine(); //nombre del subgerente
        System.out.print("Ingrese su fecha de nacimiento (DD/MM/AAAA): ");
        String fechaNacimiento = validarFecha(); //fecha de nacimiento del subgerente

        //usuario del subgerente
        String nombreUsuario;
        do {
            System.out.print("Ingrese un nombre de usuario: ");
            nombreUsuario = scanner.nextLine();
            if (existeSubgerente(nombreUsuario)) {
                System.out.println("El nombre de usuario ya existe. Ingrese con otro.");
            }
        } while (existeSubgerente(nombreUsuario));

        //---------------------------------------------------------

        System.out.print("Ingrese una contraseña: ");
        String contrasenia = scanner.nextLine();

        System.out.print("Ingrese un correo electrónico: ");
        String correo = scanner.nextLine();

        // Crear gerente
        SubGerente subgerente = new SubGerente(idSubgerente, nombre, fechaNacimiento, contrasenia, nombreUsuario,correo);
        System.out.println("Subgerente creado con exito.....");
        subgerentes.add(subgerente);
        contadores[4]++;

        //-------------------------------------- Registrar movimiento en el banco ---------------------------------------

        if(tipo_usuario==0){
            //si el usuario es admin
            movimientos[cont_movimientos] =
                    "Acción: El administrador ha creado una cuenta.\n" +
                            "Rol: Subgerente\n" +
                            "Nombre de usuario: " + nombreUsuario + "\n" +
                            "Fecha: " + fechaActual();
        }
        cont_movimientos++;
    }

    //Metodo para listar gerentes
    public void listarSubgerente() {

        //ver si la lista está llena o vacia
        boolean tieneCuentas = false;
        for (SubGerente user : subgerentes) {tieneCuentas = true;}

        if(tieneCuentas){
            System.out.println("\n ─────────── SUBGERENTES DEL BANCO ───────────");
            System.out.println("\n");
            System.out.println("| ID |  Nombre completo |       Usuario        |  Correo electrónico |");
            System.out.println("|----|------------------|----------------------|---------------------|");

            for (SubGerente user : subgerentes) {
                System.out.printf("| %-3s | %-16s | %-14s | %-16s |\n",
                        user.getIdSubgerente(),
                        user.getNombre(),
                        user.getNombreUsuario(),
                        user.getCorreo());
            }
        }else{
            System.out.println("No hay Subgerentes registrados.");
        }
        System.out.println("\n ───────────────────────────────────────────────────────");
    }

    //Metodo para editar gerente
    public void editarSubgerente(int id_usuario, int tipo_usuario){
        listarSubgerente();
        System.out.println("Ingresa el ID del subgerente a editar: ");
        String id = scanner.nextLine();

        //ver si se encontró coincidencia
        String encontrado = buscarSubgerente(id);

        //si hay coincidencia entonces edita
        if(!encontrado.equals("0")) {

            //recuperar info principal del gerente
            SubGerente subgerenteEncontrado = null;
            for(SubGerente user: subgerentes){
                if(user.getIdSubgerente().equals(String.valueOf(id))){
                    subgerenteEncontrado = user;
                }
            }


            //empezar a editar información
            System.out.println(" ꒰◌; Edita la información del subgerente (Deja el espacio en blanco en caso de no modificar dicho campo) ");

            System.out.println("Ingresa el nombre completo: ");
            String nombre = scanner.nextLine();
            if(nombre.isBlank()){
                nombre = subgerenteEncontrado.getNombre();
            }

            System.out.println("Ingresa el correo electrónico: ");
            String correo = scanner.nextLine();
            if(correo.isBlank()){
                correo = subgerenteEncontrado.getCorreo();
            }

            System.out.println("Ingresa el usuario: ");
            String usuario = scanner.nextLine();
            if(usuario.isBlank()){
                usuario = subgerenteEncontrado.getNombreUsuario();
            }

            System.out.println("Ingresa la contraseña: ");
            String contrasenia = scanner.nextLine();
            if(contrasenia.isBlank()){
                contrasenia= subgerenteEncontrado.getContrasenia();
            }

            String confirmar = confirmar_Decision();

            //guardar cambios
            if(confirmar.equals("1")){
                subgerenteEncontrado.setNombre(nombre);
                subgerenteEncontrado.setCorreo(correo);
                subgerenteEncontrado.setNombreUsuario(usuario);
                subgerenteEncontrado.setContrasenia(contrasenia);
                System.out.println("\n Subgerente actualizado con exito.");

                //--------------------------------------- Registrar el movimiento en el banco --------------------------------------------------------------------

                if(tipo_usuario==0){
                    //si el usuario es admin
                    movimientos[cont_movimientos] = ("Acción: El administrador ha editado una cuenta.\n" +
                                    "Rol: Subgerente\n" +
                                    "Nombre de usuario: " + subgerenteEncontrado.getNombreUsuario() + "\n" +
                                    "Fecha: " + fechaActual());
                }
                cont_movimientos++;
            }else{
                System.out.println("\n Operacion cancelada.");
            }

        } else {
            System.out.println("No existe un subgerente con ese id.");
        }


    }

    //Metodo para eliminar gerente
    public void eliminarSubgerente(int id_usuario, int tipo_usuario){

        listarSubgerente();

        //ver si la lista está llena o vacia
        boolean tieneCuentas = false;
        for (SubGerente user : subgerentes) {tieneCuentas = true;}


        //si hay gerentes que eliminar
        if(tieneCuentas){

            System.out.println("Ingresa el ID del subgerente a eliminar: ");
            String id = scanner.nextLine();

            //ver si se encontró coincidencia
            String encontrado = buscarSubgerente(id);

            //recuperar info principal del gerente
            SubGerente subgerenteEncontrado = null;
            for(SubGerente user: subgerentes){
                if(user.getIdSubgerente().equals(String.valueOf(id))){
                    subgerenteEncontrado = user;
                }
            }

            //recuperar el nombre del usuario del subgerente
            String usuario = subgerenteEncontrado.getNombreUsuario();

            //si hay coincidencia entonces
            if(!encontrado.equals("0")) {

                String confirmar = confirmar_Decision();

                //eliminar gerente
                if(confirmar.equals("1")){
                    subgerentes.remove(subgerenteEncontrado);
                    System.out.println("\n Subgerente eliminado con exito.");

                    //--------------------------------------- Registrar el movimiento en el banco --------------------------------------------------------------------

                    if(tipo_usuario==0){
                        //si el usuario es admin
                        movimientos[cont_movimientos] =
                                ("Acción: El administrador ha editado una cuenta.\n" +
                                        "Rol: Subgerente\n" +
                                        "Nombre de usuario: " + usuario + "\n" +
                                        "Fecha: " + fechaActual());
                    }
                    cont_movimientos++;

                }else{
                    System.out.println("\n Operacion cancelada.");
                }


            }else{
                System.out.println("No existe un gerente con ese id.");
            }
        }
    }

    //--------------------------------------------------------------------------------

    //metodo para actualizar saldo con intereses de una subcuenta
    public void actualizarSaldoConInteres(int semanaActual) {

        for(SubCuenta subcuentas : subCuentas) {
            if (subcuentas.getTipoCuenta().equals("Ahorro") || subcuentas.getTipoCuenta().equals("Plazo Fijo")){
                int semanasTranscurridas = semanaActual - subcuentas.getSemanaUltimaConsulta();
                if (semanasTranscurridas > 0) {
                    double tasaInteres = 0.0005; //ejemplo 0.05% semanal
                    double saldoConInteres = subcuentas.getSaldo() * Math.pow(1 + tasaInteres, semanasTranscurridas);
                    subcuentas.setSaldo(saldoConInteres);
                    subcuentas.setSemanaUltimaConsulta(semanaActual); //actualizar la última semana consultada
                }
            }
        }
    }

    //---------------------------------------------------------------------------------------------------------------------------------------------

    //Subcuentas

    //menu para elegir el tipo de cuenta
    public String menuTipoCuentas(){
        System.out.println("1. Ahorro");
        System.out.println("2. Corriente");
        System.out.println("3. Plazo Fijo");
        System.out.println("4. Nomina");
        System.out.println("Selecciona una opcion");
        int opcion = scanner.nextInt();
        do {
            if (opcion > 4 || opcion < 1) {
                System.out.println("Opcion invalida. Ingrese de nuevo");
                opcion = scanner.nextInt();
            }
        }while(opcion < 1 || opcion > 4);

        return switch (opcion) {
            case 1 -> "Ahorro";
            case 2 -> "Corriente";
            case 3 -> "Plazo fijo";
            case 4 -> "Nómina";
            default -> "";
        };
    }

    //Metodo para generar subcuenta  YA NO SE USA
    public void generarCuentaInversion(int id_usuario, int tipo_usuario) {

        //simular saldo con intereses
        contadores[6]++;
        actualizarSaldoConInteres(contadores[6]);

        if(contadores[0] == 1){
            System.out.println("No hay cuentas (eje) registradas");
            return;
        }

        String idCuenta = String.valueOf(contadores[0]);
        String numeroSubTarjeta = generarNumeroTarjeta();
        String claveSubInterbancaria = generarClaveInterbancaria();
        String claveSubTransferencia = generarClaveTransferencia();

        int idCuentaUsuario = 0;

        //comprobar que el numero de cuenta no exista
        do {
            if (existeNumeroTarjeta(numeroSubTarjeta)) {
                numeroSubTarjeta = generarNumeroTarjeta();
            }
        } while (existeNumeroTarjeta(numeroSubTarjeta));


        //empezar a recuperar los datos del cliente
        System.out.println(" ꒰◌; Ingresa el número de la cuenta eje del usuario: ");
        String numeroCuentaeje = validarSoloNumeros();
        System.out.println(" ꒰◌; Ingresa el nip de la cuenta eje del usuario: ");
        String nipCuentaeje = validarSoloNumeros();

        String idUsuario = "";

        for (Cuenta user : cuentas) {
            if (user.getNumeroTarjeta().equals(numeroCuentaeje) && user.getNip().equals(nipCuentaeje)) {
                System.out.println("Ingreso exitoso!");
                System.out.println(" ───────────");
                idCuentaUsuario = Integer.parseInt(user.getIdCuenta());
                idUsuario = user.getIdCuenta();
            }
        }

        String Nombre = ""; //recuperar nombre de gerente

        if(tipo_usuario==2){
            //subgerente
            for (SubGerente user : subgerentes) {
                if (user.getIdSubgerente().equals(String.valueOf(id_usuario))) {
                    Nombre=user.getNombreUsuario();
                }
            }
        }else if(tipo_usuario==0){
            //administrador
            Nombre = "administrador";
        }

        //Buscar la cuenta eje con el id recuperado
        Cuenta cuentaEje = null;
        for (Cuenta user : cuentas) {
            if (Integer.parseInt(user.getIdCuenta()) == idCuentaUsuario) {
                cuentaEje = user;
                break;
            }
        }

        //Buscar la usuario de la cuenta eje con el id recuperado
        Usuario usuarioEje = null;
        for (Usuario usuario : usuarios) {
            if (usuario.getIdUsuario().equals(cuentaEje.getIdUsuario())) {
                usuarioEje = usuario;
                break;
            }
        }

        //Recuperar titular de la cuenta
        String titular = usuarioEje.getNombre();

        if (cuentaEje != null) {
            // Recuperar los datos del titular
            System.out.println("Datos del titular de la cuenta eje:");
            System.out.println("\nDatos del usuario:");
            System.out.println("ID de usuario: " + usuarioEje.getIdUsuario());
            System.out.println("Nombre: " + usuarioEje.getNombre());
            System.out.println("Fecha de nacimiento (DD/MM/AAAA): " + usuarioEje.getFechaNacimiento());
            System.out.println("Nombre de usuario: " + usuarioEje.getNombreUsuario());
            System.out.println("Correo electrónico: " + usuarioEje.getCorreoElectronico());
        } else {
            System.out.println("No se encontró la cuenta eje.");
        }
        System.out.println("Número de la subcuenta: " + numeroSubTarjeta);

        scanner.nextLine();
        System.out.println("Ingrese el tipo de cuenta: ");
        String tipoSubCuenta = menuTipoCuentas();
        scanner.nextLine();
        System.out.print("Ingresa un nip: ");
        String nip = validarSoloNumeros();
        scanner.nextLine();
        System.out.print("Ingresa el saldo inicial de la cuenta: ");
        double saldo = validarNumeroPositivo();
        do{
            if (saldoInicial < saldo) {
                System.out.println("Cantidad invalida. Ingrese otra");
                saldo = validarNumeroPositivo();
            }
        }while(saldoInicial < saldo);

        //restar al saldo del banco el dinero otrogado a la tarjeta
        saldoInicial=saldoInicial-saldo;

        String [] movimientosc = new String [99];
        int cont_movimientosc = 0;
        boolean estado = true; //activar la tarjeta

        String confirmar = confirmar_Decision();

        if(confirmar.equals("1")){
            //--------------------------------------- Registrar el movimiento en el banco --------------------------------------------------------------------

            //administrador no ocupa aprobacion
            if(tipo_usuario==0){
                SubCuenta subcuenta = new SubCuenta(idCuenta,tipoSubCuenta,numeroSubTarjeta, claveSubInterbancaria, claveSubTransferencia,idUsuario,nip,saldo,movimientosc,cont_movimientosc,estado, contadores[6]);
                contadores[9]++;
                subCuentas.add(subcuenta);
                System.out.println("\n Subcuenta creada con exito.");
                System.out.println(" ───────────");
                movimientos[cont_movimientos] =
                        "Acción: El administrador ha creado una subcuenta bancaria.\n" +
                                "Rol: Usuario\n" +
                                "Titular:  " + titular + "\n" +
                                "Fecha: " + fechaActual();
            } else if(tipo_usuario==2){
                //subgerente ocupa aprobacion
                for(SubGerente user: subgerentes){
                    SubCuenta subcuenta = new SubCuenta(idCuenta,tipoSubCuenta,numeroSubTarjeta, claveSubInterbancaria, claveSubTransferencia,idUsuario,nip,saldo,movimientosc,cont_movimientosc,estado, contadores[6]);
                    contadores[9]++;
                    subCuentas.add(subcuenta);
                    enviarSolicitud(idUsuario,numeroSubTarjeta);
                    System.out.println("\n Subcuenta enviada para revisión con exito.");
                    System.out.println(" ───────────");
                    if(user.getIdSubgerente().equals(String.valueOf(id_usuario))){
                        movimientos[cont_movimientos] =
                                "Acción: El subgerente " + user.getNombreUsuario() + " ha enviado una solicitud de apertura de subcuenta bancaria.\n" +
                                        "Rol: Usuario\n" +
                                        "Titular:  " + titular + "\n" +
                                        "Fecha: " + fechaActual();
                    }
                }
            }
            cont_movimientos++;

        }else{
            System.out.println("\n Operacion cancelada.");
            System.out.println(" ───────────");
        }

    }

    //Metodo para listado de subcuentas
    public void listarCuentaInversion(){
        //ver si la lista está llena o vacia
        boolean tieneSubCuentas = false;
        for (SubCuenta user : subCuentas) {tieneSubCuentas = true;}

        if(tieneSubCuentas){
            System.out.println("\n ─────────── SUBCUENTAS DEL BANCO ───────────");
            System.out.println("\n");
            System.out.println("| ID |  Numero de Cuenta | Id Usuario |  Tipo de cuenta  |   Saldo   |  Estado  |");
            System.out.println("|----|-------------------|------------|------------------|-----------|----------|");

            for (SubCuenta user : subCuentas) {
                System.out.printf("| %-3s | %-16s | %-6s | %-10s | %-8s | %-8s |\n",
                        user.getIdCuenta(),
                        user.getSubNumeroTarjeta(),
                        user.getIdUsuario(),
                        user.getTipoCuenta(),
                        user.getSaldo(),
                        user.getEstado());
            }
        }else{
            System.out.println("No hay Subcuentas registrados.");
        }
        System.out.println("\n ───────────────────────────────────────────────────────");
    }

    //Metodo para buscar el usuario dado el ID
    public String buscarSubCuenta(String id){
        for (SubCuenta user : subCuentas) {
            if (user.getIdCuenta().equals(String.valueOf(id))) {
                return user.getIdUsuario();
            }
        }
        return "0";
    }

    //metodo para editar una subcuenta
    public void editarCuentaInversion(int id_usuario, int tipo_usuario){
        listarCuentaInversion();

        System.out.println("Ingresa el ID del subcuenta a editar: ");
        String id = scanner.nextLine();
        //ver si se encontró coincidencia
        String encontrado = buscarSubCuenta(id);

        //si hay coincidencia entonces edita
        if(!encontrado.equals("0")) {

            //recuperar info principal del gerente
            SubCuenta subCuentaEncontrado = null;
            for(SubCuenta user: subCuentas){
                if(user.getIdCuenta().equals(String.valueOf(id))){
                    subCuentaEncontrado = user;
                }
            }


            //empezar a editar información
            System.out.println(" ꒰◌; Edita la información de la subcuenta (Deja el espacio en blanco en caso de no modificar dicho campo) ");

            System.out.println("Desea editar el nip: ");
            String nip = scanner.nextLine();
            if(nip.isBlank()){
                nip = subCuentaEncontrado.getNip();
            }


            String confirmar = confirmar_Decision();

            //guardar cambios
            if(confirmar.equals("1")){
                subCuentaEncontrado.setNip(nip);
                System.out.println("\n Nip de Subcuenta actualizado con exito.");

                //--------------------------------------- Registrar el movimiento en el banco --------------------------------------------------------------------

                //administrador
                if(tipo_usuario==0){
                    movimientos[cont_movimientos] =
                            "Acción: El administrador ha editado una subcuenta.\n" +
                                    "Rol: Usuario\n" +
                                    "Número de cuenta:  " + subCuentaEncontrado.getSubNumeroTarjeta() + "\n" +
                                    "Fecha: " + fechaActual();
                }else if(tipo_usuario==2) {
                    //subgerentes
                    for (SubGerente user : subgerentes) {
                        if (user.getIdSubgerente().equals(String.valueOf(id_usuario))) {
                            movimientos[cont_movimientos] =
                                    "Acción: El subgerente " +user.getNombreUsuario()+ " ha editado el nip de una subcuenta.\n" +
                                            "Rol: Usuario\n" +
                                            "Número de cuenta:  " + subCuentaEncontrado.getSubNumeroTarjeta() + "\n" +
                                            "Fecha: " + fechaActual();
                        }
                    }
                }
                cont_movimientos++;
            }else{
                System.out.println("\n Operacion cancelada.");
            }

        } else {
            System.out.println("No existe un subcuenta con ese id.");
        }





    }

    //metodo para eliminar una subcuenta
    public void eliminarCuentaInversion(int id_usuario, int tipo_usuario){
        listarCuentaInversion();

        //ver si la lista está llena o vacia
        boolean tieneSubCuentas = false;
        for (SubCuenta user : subCuentas) {tieneSubCuentas = true;}

        //si hay SubCunetas que eliminar
        if(tieneSubCuentas){

            System.out.println("Ingresa el ID de la subcuenta a eliminar: ");
            String id = scanner.nextLine();

            //ver si se encontró coincidencia
            String encontrado = buscarSubCuenta(id);

            //recuperar info principal del gerente
            SubCuenta subCuentaEncontrado = null;
            for(SubCuenta user: subCuentas){
                if(user.getIdCuenta().equals(String.valueOf(id))){
                    subCuentaEncontrado = user;
                }
            }

            //si hay coincidencia entonces
            if(!encontrado.equals("0")) {

                String confirmar = confirmar_Decision();
                //eliminar Subcuenta
                if(confirmar.equals("1")){

                    //guardar numero de subcuenta
                    String numeroCuenta = subCuentaEncontrado.getSubNumeroTarjeta();
                    subCuentas.remove(subCuentaEncontrado);
                    System.out.println("\n SubCuenta eliminado con exito.");

                    //--------------------------------------- Registrar el movimiento en el banco --------------------------------------------------------------------

                    //administrador
                    if(tipo_usuario==0){
                        movimientos[cont_movimientos]=("El administrador ha eliminado la subcuenta bancaria" + numeroCuenta + " en la fecha " + fechaActual());
                    }else if(tipo_usuario==2) {
                        //subgerentes
                        for (SubGerente user : subgerentes) {
                            if (user.getIdSubgerente().equals(String.valueOf(id_usuario))) {
                                movimientos[cont_movimientos] =
                                        "Acción: El subgerente " +user.getNombreUsuario() + " ha eliminado una subcuenta.\n" +
                                                "Rol: Usuario\n" +
                                                "Número de cuenta:  " + numeroCuenta + "\n" +
                                                "Fecha: " + fechaActual();
                            }
                        }
                    }
                    cont_movimientos++;

                }else{
                    System.out.println("\n Operacion cancelada.");
                }


            }else{
                System.out.println("No existe una subcuenta con ese id.");
            }
        }


    }

    //---------------------------------------------------------------------------------------------------------

    //Cuenta Bancaria

    //Metodo para buscar el nombre dado el id
    public String buscarNombre(int id_usuario){
        for (Usuario user : usuarios) {
            if (user.getIdUsuario().equals(String.valueOf(id_usuario))) {
                return user.getNombreUsuario();
            }
        }
        return "";
    }




    //Metodo para generar el numero de cuenta
    public String generarNumeroTarjeta() {
        long min = 10_000_000L;
        long max = 99_999_999L;
        return String.valueOf(min + ((long) (random.nextDouble() * (max - min))));
    }

    public String generarClaveInterbancaria() {
        long min = 1_000_000_000_000L;
        long max = 9_999_999_999_999L;
        return String.valueOf(min + ((long) (random.nextDouble() * (max - min))));
    }

    public String generarClaveTransferencia() {
        long min = 1_000_000_000_000_000L;
        long max = 9_999_999_999_999_999L;
        return String.valueOf(min + ((long) (random.nextDouble() * (max - min))));
    }

    //Metodo para verificar si el número de cuenta ya existe
    public boolean existeNumeroTarjeta(String numeroTarjeta) {

        //si existe como cuenta eje
        for (Cuenta cuenta : cuentas) {
            if (cuenta.getNumeroTarjeta().equals(numeroTarjeta)) {
                return true; //El número de cuenta ya está en uso
            }
        }
        //si existe como subcuenta
        for (SubCuenta subcuenta : subCuentas) {
            if (subcuenta.getSubNumeroTarjeta().equals(numeroTarjeta)) {
                return true; //El número de subcuenta ya está en uso
            }
        }
        return false; //El número de cuenta es único
    }

    //Metodo para verificar si el número de cuenta ya existe
    public boolean existeClaveInterbancaria(String claveInterbancaria) {

        //si existe como cuenta eje
        for (Cuenta cuenta : cuentas) {
            if (cuenta.getClaveInterbancaria().equals(claveInterbancaria)) {
                return true; //El número de cuenta ya está en uso
            }
        }
        //si existe como subcuenta
        for (SubCuenta subcuenta : subCuentas) {
            if (subcuenta.getSubClaveInterbancaria().equals(claveInterbancaria)) {
                return true; //El número de subcuenta ya está en uso
            }
        }
        return false; //El número de cuenta es único
    }

    //Metodo para verificar si el número de cuenta ya existe
    public boolean existeClaveTransferencia(String ClaveTransferencia) {

        //si existe como cuenta eje
        for (Cuenta cuenta : cuentas) {
            if (cuenta.getNumeroTarjeta().equals(ClaveTransferencia)) {
                return true; //El número de cuenta ya está en uso
            }
        }
        //si existe como subcuenta
        for (SubCuenta subcuenta : subCuentas) {
            if (subcuenta.getSubClaveTransferencia().equals(ClaveTransferencia)) {
                return true; //El número de subcuenta ya está en uso
            }
        }
        return false; //El número de cuenta es único
    }








    //Metodo para verificar si el usuario ya existe
    private boolean existeUsuario(String nombreUsuario) {
        for (Usuario user : usuarios) {
            if (user.getNombreUsuario().equals(nombreUsuario)) {
                return true; //El gerente ya existe
            }
        }
        return false;
    }

    //Metodo para aperturar una cuenta principal en el banco así como un usuario NO SE USA YA
    public void aperturarCuenta(int id_usuario, int tipo_usuario){

        String idCuenta = String.valueOf(contadores[0]);
        String idUsuario = String.valueOf(contadores[1]);
        String tipoCuenta = "eje";
        String numeroTarjeta = generarNumeroTarjeta();
        String claveInterbancaria = generarClaveInterbancaria();
        String claveTransferencia = generarClaveTransferencia();


        //comprobar que el numero de cuenta no exista
        do{
            if (existeNumeroTarjeta(numeroTarjeta)) {
                numeroTarjeta = generarClaveInterbancaria();
            }
        } while(existeNumeroTarjeta(numeroTarjeta));

        //empezar a solicitar datos del cliente
        System.out.println(" ꒰◌; Ingresa la información del cliente: ");

        System.out.println("Numero de tarjeta: "+ numeroTarjeta);
        System.out.print("Nombre del titular: ");
        String titular = scanner.nextLine();
        System.out.print("Fecha de nacimiento del titular (DD/MM/AAAA): ");
        String fecha = validarFecha();
        System.out.print("Ingresa un nip: ");
        String nip = validarSoloNumeros();
        System.out.print("Ingresa el saldo inicial de la cuenta: ");
        double saldo = validarNumeroPositivo();
        do{
            if (saldoInicial < saldo) {
                System.out.println("Cantidad invalida. Ingrese otra");
                saldo = validarNumeroPositivo();
            }
        }while(saldoInicial < saldo);

        //restar al saldo del banco el dinero otrogado a la tarjeta
        saldoInicial=saldoInicial-saldo;

        String [] movimientosc = new String [99];
        int cont_movimientosc=0;
        boolean estado = true; //activar la tarjeta

        //empezar a solicitar datos del usuario
        System.out.println("\n \n ꒰◌; Ingresa la información de la cuenta de la aplicación: ");

        String nusuario;
        do {
            System.out.print("Nombre del usuario: ");
            nusuario = scanner.nextLine();
            if (existeUsuario(nusuario)) {
                System.out.println("El nombre de usuario ya existe. Ingrese con otro.");
            }
        } while(existeUsuario(nusuario));

        System.out.print("Ingresa una contraseña: ");
        String contrasenia = scanner.nextLine();
        System.out.print("Ingresa un correo electrónico: ");
        String correo = scanner.nextLine();

        String confirmar = confirmar_Decision();

        //crear cuenta
        if(confirmar.equals("1")){
            Usuario usuario = new Usuario(idUsuario,titular,fecha,contrasenia,nusuario,correo);
            Cuenta cuenta = new Cuenta(idCuenta,tipoCuenta,numeroTarjeta, claveInterbancaria,claveTransferencia,idUsuario,nip,saldo,movimientosc,cont_movimientosc,estado);
            contadores[0]++;
            contadores[1]++;
            cuentas.add(cuenta);
            usuarios.add(usuario);
            System.out.println("\n Cuenta y usuario creados con exito.");
            System.out.println(" ───────────");

            //--------------------------------------- Registrar el movimiento en el banco --------------------------------------------------------------------

           //administrador
            if(tipo_usuario==0){
                movimientos[cont_movimientos] =
                        "Acción: El administrador ha creado una cuenta bancaria.\n" +
                                "Rol: Usuario\n" +
                                "Titular:  " + titular + "\n" +
                                "Fecha: " + fechaActual();
            }
            cont_movimientos++;

        }else{
            System.out.println("\n Operacion cancelada.");
            System.out.println(" ───────────");
        }
    }

    //Metodo para listar todas las cuentas
    public void listarCuentas(){

        //ver si la lista está llena o vacia
        boolean hayCuentas = false;
        String estado="";

        for (Cuenta user : cuentas) {hayCuentas = true;}

        if(hayCuentas){
            System.out.println("\n ─────────── CUENTAS DEL BANCO ───────────");
            System.out.println("\n");
            System.out.println("| ID |  Numero de Cuenta | Titular |    Saldo    |  Estado  |");
            System.out.println("|----|-------------------|---------|-------------|----------|----------|");

            for (Cuenta user : cuentas) {
                for(Usuario titular : usuarios){
                    if(titular.getIdUsuario().equals(user.getIdUsuario())){
                        if(user.getEstado()){estado="Encendida";}
                        else if(!user.getEstado()){estado="Apagada";}
                        System.out.printf("| %-3s | %-16s | %-6s | %-10s | %-8s |\n",
                                user.getIdCuenta(),
                                user.getNumeroTarjeta(),
                                titular.getNombreUsuario(),
                                user.getSaldo(),
                                estado);
                    }
                }
            }

        }else{
            System.out.println("No hay Cuentas registrados.");
        }
        System.out.println("\n ───────────────────────────────────────────────────────");
    }

    //Metodo para buscar el nombre del usuario dado el ID
    public String buscarCuenta(String id){
        for (Cuenta user : cuentas) {
            if (user.getIdCuenta().equals(String.valueOf(id))) {
                return user.getIdUsuario();
            }
        }
        return "0";
    }

    //Metodo para editar una cuenta
    public void editarCuentas(int id_usuario, int tipo_usuario){

        listarCuentas();
        System.out.println("Ingresa el ID de la cuenta a editar: ");
        String id = scanner.nextLine();

        //ver si se encontró coincidencia
        String encontrado = buscarCuenta(id);

        //si hay coincidencia entonces edita
        if(!encontrado.equals("0")) {

            //recuperar info principal de la cuenta encontrada
            Cuenta CuentaEncontrado = null;
            for(Cuenta user: cuentas){
                if(user.getIdCuenta().equals(String.valueOf(id))){
                    CuentaEncontrado = user;
                }
            }


            //empezar a editar información
            System.out.println(" ꒰◌; Edita la información de la cuenta (Deja el espacio en blanco en caso de no modificar dicho campo) ");

            System.out.println("Desea editar el nip: ");
            String nip = scanner.nextLine();
            if(nip.isBlank()){
                nip = CuentaEncontrado.getNip();
            }

            String confirmar = confirmar_Decision();

            //guardar cambios
            if(confirmar.equals("1")){
                CuentaEncontrado.setNip(nip);
                System.out.println("\n Nip de Cuenta actualizado con exito.");

                //--------------------------------------- Registrar el movimiento en el banco --------------------------------------------------------------------

                //administrador
                if(tipo_usuario==0){
                    movimientos[cont_movimientos] =
                            "Acción: El administrador ha editado el nip de una cuenta bancaria.\n" +
                                    "Rol: Usuario\n" +
                                    "Número de cuenta:  " + CuentaEncontrado.getNumeroTarjeta() + "\n" +
                                    "Fecha: " + fechaActual();
                }
                cont_movimientos++;

            }else{
                System.out.println("\n Operacion cancelada.");
            }

        } else {
            System.out.println("No existe un Cuenta con ese id.");
        }





    }

    //Metodo para eliminar una cuenta
    public void eliminarCuentas(int id_usuario, int tipo_usuario){

        listarCuentas();

        //ver si la lista está llena o vacia
        boolean hayCuentas = false;
        for (Cuenta user : cuentas) {hayCuentas = true;}

        //si hay Cuentas que eliminar
        if(hayCuentas){


            System.out.println("Ingresa el ID de la cuenta a eliminar: ");
            String id = scanner.nextLine();

            //ver si se encontró coincidencia
            String encontrado = buscarCuenta(id);

            //recuperar info principal de la cuenta
            Cuenta CuentaEncontrado = null;
            for(Cuenta user: cuentas){
                if(user.getIdCuenta().equals(String.valueOf(id))){
                    CuentaEncontrado = user;
                }
            }

            //si hay coincidencia entonces
            if(!encontrado.equals("0")) {

                String confirmar = confirmar_Decision();
                //eliminar Subcuenta
                if(confirmar.equals("1")){

                    cuentas.remove(CuentaEncontrado);
                    System.out.println("\n SubCuenta eliminado con exito.");

                    //--------------------------------------- Registrar el movimiento en el banco --------------------------------------------------------------------


                    //administrador
                    if(tipo_usuario==0){
                        movimientos[cont_movimientos] =
                                "Acción: El administrador ha eliminado una cuenta bancaria.\n" +
                                        "Rol: Usuario\n" +
                                        "Número de cuenta:  " + CuentaEncontrado.getNumeroTarjeta() + "\n" +
                                        "Fecha: " + fechaActual();
                    }
                    cont_movimientos++;

                }else{
                    System.out.println("\n Operacion cancelada.");
                }


            }else{
                System.out.println("No existe una cuenta con ese id.");
            }
        }


    }

    //Metodo para consultar saldo
    public void consultarSaldo(int idUsuario) {
        for (Cuenta cuenta : cuentas) {
            if (cuenta.getIdUsuario().equals(String.valueOf(idUsuario))) {
                System.out.println("Saldo actual de la cuenta:  $ " + cuenta.getSaldo());
                return;
            }
        }
    }

    //---------------------------------------------------------------------------------------------------------

    //Cajero

    //Metodo para entrar al cajero
    public int SesionCajero() {
        System.out.println("\n \n ───────────");
        System.out.print("Ingrese el numero de tarjeta: ");
        String tarjeta = validarSoloNumeros();
        System.out.print("Ingrese el nip: ");
        String nip = validarSoloNumeros();

        for (Cuenta user : cuentas) {
            if (user.getNumeroTarjeta().equals(tarjeta) && user.getNip().equals(nip)) {
                System.out.println("Ingreso exitoso!");
                System.out.println(" ───────────");
                return Integer.parseInt(user.getIdCuenta());
            }
        }

        System.out.println("Tarjeta y/o NIP incorrecto ! ! !");
        System.out.println(" ───────────");
        return 0;
    }

    //Metodo para retirar dinero
    public void retirarDinero(int idUsuario) {

        //recuperar información de la cuenta bancaria
        Cuenta cuentaEncontrada = null;
        for (Cuenta cuenta : cuentas) {
            if (String.valueOf(idUsuario).equals(cuenta.getIdUsuario())) {
                cuentaEncontrada = cuenta;
                break;
            }
        }

        //hacer transaccion si la tarjeta está prendida
        if(cuentaEncontrada.getEstado()){
            boolean retiroExitoso = false;

            //proceso para validar el retiro
            do {
                double saldoActual = cuentaEncontrada.getSaldo();
                System.out.println("Ingresa la cantidad de dinero a retirar: ");
                double cantidadRetirar = validarNumeroPositivo();

                if (cantidadRetirar > saldoActual) {
                    System.out.println("El saldo en la cuenta no es suficiente!");
                    System.out.println("Su saldo actual es de: $" + saldoActual);
                } else if (cantidadRetirar < 0) {
                    System.out.println("Ingrese un número válido!");
                } else {
                    double saldoanterior = cuentaEncontrada.getSaldo();
                    cuentaEncontrada.setSaldo(saldoActual - cantidadRetirar);
                    retiroExitoso = true;
                    System.out.println("Retiro exitoso! Nuevo saldo: $" + cuentaEncontrada.getSaldo());
                    //guadar el movimiento de retiro
                    String mensajeTransferencia = String.format(
                            " Se han retirado: %s\n" +
                                    "  - Cantidad retirada: $%.2f\n" +
                                    "  - Saldo anterior: $%.2f\n" +
                                    "  - Saldo actual: $%.2f\n",
                            cantidadRetirar,
                            cantidadRetirar,
                            saldoanterior,
                            cuentaEncontrada.getSaldo()
                    );
                    cuentaEncontrada.setMovimientos(mensajeTransferencia, cuentaEncontrada.getCont_movimientos());
                }
            } while (!retiroExitoso);
        }else{
            System.out.println(" Ha ocurrido un error ");
        }
    }

    //Metodo para deposito de dinero
    public void depositarDinero(int idUsuario) {

        //recuperar información de la cuenta bancaria
        Cuenta cuentaEncontrada = null;
        for (Cuenta cuenta : cuentas) {
            if (String.valueOf(idUsuario).equals(cuenta.getIdUsuario())) {
                cuentaEncontrada = cuenta;
                break;
            }
        }

        boolean depositoExitoso = false;
        do {
            double saldoActual = cuentaEncontrada.getSaldo();
            System.out.println("Ingrese la cantidad a depositar: ");
            double cantidadDepositar = validarNumeroPositivo();

            if (cantidadDepositar < 0) {
                System.out.println("Ingrese un número válido!");
            } else {
                double saldoanterior = cuentaEncontrada.getSaldo();
                cuentaEncontrada.setSaldo(saldoActual + cantidadDepositar);
                depositoExitoso = true;
                System.out.println("Deposito exitoso! Nuevo saldo: $" + cuentaEncontrada.getSaldo());
                //guardar mensaje de deposito
                String mensajeTransferencia = String.format(
                        " Se han depositado: %s\n" +
                                "  - Cantidad depositada: $%.2f\n" +
                                "  - Saldo anterior: $%.2f\n" +
                                "  - Saldo actual: $%.2f\n",
                        cantidadDepositar,
                        cantidadDepositar,
                        saldoanterior,
                        cuentaEncontrada.getSaldo()
                );
                cuentaEncontrada.setMovimientos(mensajeTransferencia, cuentaEncontrada.getCont_movimientos());
            }
        } while (!depositoExitoso);
    }

    //---------------------------------------------------------------------------------------------------------

    //Aplicación

    //Metodo para entrar a la aplicación
    public int SesionAplicacion() {
        System.out.println("\n \n ───────────");
        System.out.print("Ingrese el usuario: ");
        String nombre = scanner.nextLine();
        System.out.print("Ingrese la contraseña: ");
        String contrasenia = scanner.nextLine();

        for (Usuario user : usuarios) {
            if (user.getNombreUsuario().equals(nombre) && user.getContrasenia().equals(contrasenia)) {
                System.out.println("Ingreso exitoso!");
                System.out.println(" ───────────");
                return Integer.parseInt(user.getIdUsuario());
            }
        }

        System.out.println("Usuario y/o contraseña incorrectos ! ! !");
        System.out.println(" ───────────");
        return 0;
    }

    //Metodo para obtener la cuenta principal del usuario
    public Cuenta obtenerCuentaPrincipal(int idUsuario) {
        for (Cuenta cuenta : cuentas) {
            if (cuenta.getIdUsuario().equals(String.valueOf(idUsuario)) && cuenta.getEstado()) {
                return cuenta; // Si la cuenta está activa, la consideramos como principal
            }
        }
        return null; // Si no se encuentra ninguna cuenta activa, devolvemos null
    }

    //Metodo para ver una cuenta del usuario
    public void verCuenta(int idUsuario) {
        // Buscar el usuario por su ID y mostrar su información
        for (Usuario usuario : usuarios) {
            if (usuario.getIdUsuario().equals(String.valueOf(idUsuario))) {
                // Información básica del usuario
                System.out.println("\n\t꒰◌; Información del perfil del usuario");
                System.out.println("|----------------------------------------------|");
                System.out.println(" ID Usuario: " + usuario.getIdUsuario());
                System.out.println(" Nombre: " + usuario.getNombreUsuario());
                System.out.println(" Fecha de nacimiento (DD/MM/AAAA): " + usuario.getFechaNacimiento());

                // Obtener y mostrar la cuenta principal
                Cuenta cuentaPrincipal = obtenerCuentaPrincipal(idUsuario);
                if (cuentaPrincipal != null) {
                    System.out.println(" Número de cuenta principal: " + cuentaPrincipal.getNumeroTarjeta());
                } else {
                    System.out.println(" No se encontró la cuenta.");
                }
                System.out.println("|----------------------------------------------|");
                return;
            }
        }
        System.out.println("Usuario no encontrado.");
    }

    //Metodo para listar cuentas asociadas al usuario
    public void mostrarCuentas(int id_usuario) {

        //Buscar cuenta principal del usuario
        System.out.println(" ꒰◌; Cuentas bancarias asociadas al usuario ");

        System.out.println("| Número de Cuenta | Tipo de Cuenta | Saldo     |");
        System.out.println("|------------------|----------------|-----------|");


        for (Cuenta user : cuentas) {
            if(user.getIdUsuario().equals(String.valueOf(id_usuario))){
                System.out.printf("| %-16s | %-14s | $%-8.2f |\n",
                        user.getNumeroTarjeta(),
                        user.getTipoCuenta(),
                        user.getSaldo());
            }
        }

        for (SubCuenta user : subCuentas) {
            if(user.getIdUsuario().equals(String.valueOf(id_usuario))){
                System.out.printf("| %-16s | %-14s | $%-8.2f |\n",
                        user.getSubNumeroTarjeta(),
                        user.getTipoCuenta(),
                        user.getSaldo());
            }
        }
    }

    //Metodo para consultar los contactos del usuario
    public void mostrarContactos(int idUsuario) {

        // Mostrar los contactos
        System.out.println(" ꒰◌; Contactos asociados al usuario ");
        System.out.println("|     Nombre       |   Numero de cuenta  |");
        System.out.println("|------------------|---------------------|");

        boolean tieneContactos = false;
        for (Contacto contacto : contactos) {
            if (String.valueOf(idUsuario).equals(contacto.getIdUsuario())) {
                System.out.printf("| %-16s | %-14s |\n",
                        contacto.getNombre(),
                        contacto.getNumeroCuenta());
                tieneContactos = true;
            }
        }

        if (!tieneContactos) {
            System.out.println("No tienes contactos agregados.");
            return; // Salir del metodo si no hay contactos
        }
    }

    //Metodo para agregar un nuevo contacto al usuario
    public void agregarContacto(int idUsuario) {
        System.out.println(" ꒰◌; Agregar un contacto nuevo ");

        System.out.print("Ingrese el nombre del contacto: ");
        String nombreContacto = scanner.nextLine();

        System.out.print("Ingrese el número de cuenta del contacto: ");
        String numeroCuenta = validarSoloNumeros();

        // Validar si el contacto ya existe
        for (Contacto contacto : contactos) {
            if (contacto.getNombre().equals(nombreContacto) && contacto.getIdUsuario().equals(String.valueOf(idUsuario)) && contacto.getNumeroCuenta().equals(numeroCuenta)) {
                System.out.println("El contacto ya está registrado en su lista.");
                return;
            }
        }

        // Si el contacto no existe guardar en la lista de contactos
        Contacto contacto = new Contacto(String.valueOf(idUsuario), nombreContacto, numeroCuenta);
        System.out.println("Contacto creado con exito.....");
        contactos.add(contacto);
        contadores[2]++;
    }

    //Metodo para consultar el saldo de una cuenta del usuario
    public void consultarSaldoCuenta(String numeroCuenta, int id_usuario) {

        boolean existe = existeNumeroTarjeta(numeroCuenta);

        //si la cuenta existe y es del usuario
        if(existe){
            for (Cuenta cuenta : cuentas) {
                if (cuenta.getIdUsuario().equals(String.valueOf(id_usuario)) && cuenta.getNumeroTarjeta().equals(numeroCuenta)) {
                    System.out.println("Saldo actual de la cuenta:  $ " + cuenta.getSaldo());
                    return;
                }
            }
            for (SubCuenta cuenta : subCuentas) {
                if (cuenta.getIdUsuario().equals(String.valueOf(id_usuario)) && cuenta.getSubNumeroTarjeta().equals(numeroCuenta)) {
                    System.out.println("Saldo actual de la cuenta:  $ " + cuenta.getSaldo());
                    return;
                }
            }
        } else {
            System.out.println(" La cuenta ingresada no se ha encontrado.");
        }
    }

    //Metodo para ver los movimientos de la cuenta (depositos, retiros y transferencias)
    public void consultarMovimientos(String numeroCuenta, int idUsuario) {

        System.out.println(" \n ꒰◌; Movimientos de la cuenta: "+ numeroCuenta);
        System.out.println("\n");

        //si es una cuenta eje
        for (Cuenta cuenta : cuentas) {
            if (cuenta.getNumeroTarjeta().equals(numeroCuenta) && cuenta.getIdUsuario().equals(String.valueOf(idUsuario))) {
                String[] movimientos = cuenta.getMovimientos();
                if (cuenta.getCont_movimientos() != 0) {
                    for (int i = 0; i < movimientos.length; i++) {
                        if (movimientos[i] != null) {
                            System.out.println((i + 1) + ". " + movimientos[i]);
                        }
                    }
                } else {
                    System.out.println("No hay movimientos registrados.");
                }
                return;
            }
        }

        //si es una subcuenta
        for (SubCuenta cuenta : subCuentas) {
            if (cuenta.getSubNumeroTarjeta().equals(numeroCuenta) && cuenta.getIdUsuario().equals(String.valueOf(idUsuario))) {
                String[] movimientos = cuenta.getMovimientos();
                if (cuenta.getCont_movimientos() != 0) {
                    for (int i = 0; i < movimientos.length; i++) {
                        if (movimientos[i] != null) {
                            System.out.println((i + 1) + ". " + movimientos[i]);
                        }
                    }
                } else {
                    System.out.println("No hay movimientos registrados.");
                }
                return;
            }
        }

        System.out.println("Cuenta no encontrada o no pertenece al usuario.");
    }

    //Metodo para verificar si existe la cuenta a la que se va a transferir el dinero
    public void comprobarCuentas(String idUsuario, double cantidadTransferir, String numeroCuenta) {

        //buscar en cuentas eje
        for (Cuenta cuenta : cuentas) {

            //si la cuenta pertenece al mismo usuario guardar el mensaje de transferencia a la otra cuenta
            if (cuenta.getNumeroTarjeta().equals(numeroCuenta) && cuenta.getIdUsuario().equals(idUsuario)) {
                double Saldoanterior = cuenta.getSaldo();
                cuenta.setSaldo(cuenta.getSaldo()+cantidadTransferir);

                String mensajeTransferencia = String.format(
                        " Transferencia realizada desde tu cuenta : %s\n" +
                                "  - Cantidad transferida: $%.2f\n" +
                                "  - Saldo anterior: $%.2f\n" +
                                "  - Saldo actual: $%.2f\n",
                        cuenta.getNumeroTarjeta(),
                        cantidadTransferir,
                        Saldoanterior,
                        cuenta.getSaldo()
                );
                cuenta.setMovimientos(mensajeTransferencia, cuenta.getCont_movimientos());
                return;
            }

            //si la cuenta no es del usuario pero pertenece al mismo banco
            if (cuenta.getNumeroTarjeta().equals(numeroCuenta)) {
                double Saldoanterior = cuenta.getSaldo();
                cuenta.setSaldo(cuenta.getSaldo()+cantidadTransferir);

                String mensajeTransferencia = String.format(
                        " Transferencia realizada desde la cuenta : %s\n" +
                                "  - Cantidad transferida: $%.2f\n" +
                                "  - Saldo anterior: $%.2f\n" +
                                "  - Saldo actual: $%.2f\n",
                        cuenta.getNumeroTarjeta(),
                        cantidadTransferir,
                        Saldoanterior,
                        cuenta.getSaldo()
                );
                cuenta.setMovimientos(mensajeTransferencia, cuenta.getCont_movimientos());
                return;
            }

        }

        //buscar en subcuentas
        for (SubCuenta subcuenta : subCuentas) {

            //si la cuenta pertenece al mismo usuario guardar el mensaje de transferencia a la otra cuenta
            if (subcuenta.getSubNumeroTarjeta().equals(numeroCuenta) && subcuenta.getIdUsuario().equals(idUsuario)) {
                double Saldoanterior = subcuenta.getSaldo();
                subcuenta.setSaldo(subcuenta.getSaldo()+cantidadTransferir);

                String mensajeTransferencia = String.format(
                        " Transferencia realizada desde tu subcuenta : %s\n" +
                                "  - Cantidad transferida: $%.2f\n" +
                                "  - Saldo anterior: $%.2f\n" +
                                "  - Saldo actual: $%.2f\n",
                        subcuenta.getSubNumeroTarjeta(),
                        cantidadTransferir,
                        Saldoanterior,
                        subcuenta.getSaldo()
                );
                subcuenta.setMovimientos(mensajeTransferencia, subcuenta.getCont_movimientos());
                return;
            }

            //si la cuenta no es del usuario pero pertenece al mismo banco
            if (subcuenta.getSubNumeroTarjeta().equals(numeroCuenta)) {
                double Saldoanterior = subcuenta.getSaldo();
                subcuenta.setSaldo(subcuenta.getSaldo()+cantidadTransferir);

                String mensajeTransferencia = String.format(
                        " Transferencia realizada desde la subcuenta : %s\n" +
                                "  - Cantidad transferida: $%.2f\n" +
                                "  - Saldo anterior: $%.2f\n" +
                                "  - Saldo actual: $%.2f\n",
                        subcuenta.getSubNumeroTarjeta(),
                        cantidadTransferir,
                        Saldoanterior,
                        subcuenta.getSaldo()
                );
                subcuenta.setMovimientos(mensajeTransferencia, subcuenta.getCont_movimientos());
                return;
            }

        }
    }

    //Metodo para transferir dinero a un contacto
    public void transferirContacto(int idUsuario) {

        System.out.println("\n꒰◌; Transferencia ");

        System.out.println("\n");
        mostrarContactos(idUsuario);

        System.out.print("\n Ingrese el nombre de su contacto: ");
        String nombreTransferir = scanner.nextLine();
        scanner.nextLine();

        String numeroTransferir="";

        //recupero el numero de cuenta del contacto
        for (Contacto contacto : contactos) {
            //si la cuenta es del banco
            if (contacto.getNombre().equals(nombreTransferir)) {
                numeroTransferir =  contacto.getNumeroCuenta();
            }
        }

        //si hay coincidencia seguir con el proceso
        if(!numeroTransferir.equals("")){

            mostrarCuentas(idUsuario);
            System.out.println("\n \n");
            System.out.print("\n Ingrese el número de cuenta de la que desea retirar: ");
            String numeroCuenta = validarSoloNumeros();

            Cuenta cuentaEncontrada = null;
            for (Cuenta cuenta : cuentas) {
                if (numeroCuenta.equals(cuenta.getNumeroTarjeta()) && String.valueOf(idUsuario).equals(cuenta.getIdUsuario())) {
                    cuentaEncontrada = cuenta;
                    break;
                }
            }

            SubCuenta subcuentaEncontrada = null;
            for (SubCuenta subcuenta : subCuentas) {
                if (numeroCuenta.equals(subcuenta.getSubNumeroTarjeta()) && String.valueOf(idUsuario).equals(subcuenta.getIdUsuario())) {
                    subcuentaEncontrada = subcuenta;
                    break;
                }
            }

            //si la transferencia es desde una cuenta eje
            if (cuentaEncontrada != null) {
                System.out.print("Ingrese el NIP de la cuenta: ");
                String nip = validarSoloNumeros();

                if (cuentaEncontrada.getNip().equals(nip)) {
                    System.out.println("Acceso permitido");

                    boolean transferenciaExitoso = false;
                    do {
                        double saldoActual = cuentaEncontrada.getSaldo();
                        System.out.print("Ingrese la cantidad a transferir: ");
                        double cantidadTransferir = scanner.nextDouble();

                        if (cantidadTransferir > cuentaEncontrada.getSaldo()) {
                            System.out.println("El saldo en la cuenta no es suficiente!");
                            System.out.println("Su saldo actual es de: $" + saldoActual);
                        } else if (cantidadTransferir < 0) {
                            System.out.println("Ingrese un número válido!");
                        } else {
                            Double saldoanterior = cuentaEncontrada.getSaldo();
                            cuentaEncontrada.setSaldo(saldoActual - cantidadTransferir);

                            //comprobar si no es una cuenta suya o de alguien del banco
                            comprobarCuentas(String.valueOf(idUsuario),cantidadTransferir,numeroTransferir);
                            transferenciaExitoso = true;
                            System.out.println("Transferencia exitosa! Nuevo saldo: $" + cuentaEncontrada.getSaldo());

                            String mensajeTransferencia = String.format(
                                    " Transferencia realizada:\n" +
                                            "  - Cantidad transferida: $%.2f\n" +
                                            "  - Cuenta de destino: %s\n" +
                                            "  - Saldo anterior: $%.2f\n" +
                                            "  - Saldo actual: $%.2f\n",
                                    cantidadTransferir,
                                    numeroTransferir,
                                    saldoanterior,
                                    cuentaEncontrada.getSaldo()
                            );

                            cuentaEncontrada.setMovimientos(mensajeTransferencia, cuentaEncontrada.getCont_movimientos());

                        }
                    } while (!transferenciaExitoso);
                } else {
                    System.out.println("Acceso denegado: PIN incorrecto");
                }


            //si la transferencia es desde una subcuenta
            } else if(subcuentaEncontrada!=null){
                System.out.print("Ingrese el NIP de la cuenta: ");
                String nip = validarSoloNumeros();

                if (subcuentaEncontrada.getNip().equals(nip)) {
                    System.out.println("Acceso permitido");

                    boolean transferenciaExitoso = false;
                    do {
                        double saldoActual = subcuentaEncontrada.getSaldo();
                        System.out.print("Ingrese la cantidad a transferir: ");
                        double cantidadTransferir = scanner.nextDouble();

                        if (cantidadTransferir > subcuentaEncontrada.getSaldo()) {
                            System.out.println("El saldo en la cuenta no es suficiente!");
                            System.out.println("Su saldo actual es de: $" + saldoActual);
                        } else if (cantidadTransferir < 0) {
                            System.out.println("Ingrese un número válido!");
                        } else {
                            Double saldoanterior = subcuentaEncontrada.getSaldo();
                            subcuentaEncontrada.setSaldo(saldoActual - cantidadTransferir);

                            //comprobar si no es una cuenta suya o de alguien del banco
                            comprobarCuentas(String.valueOf(idUsuario),cantidadTransferir,numeroTransferir);
                            transferenciaExitoso = true;
                            System.out.println("Transferencia exitosa! Nuevo saldo: $" + subcuentaEncontrada.getSaldo());

                            String mensajeTransferencia = String.format(
                                    " Transferencia realizada:\n" +
                                            "  - Cantidad transferida: $%.2f\n" +
                                            "  - Cuenta de destino: %s\n" +
                                            "  - Saldo anterior: $%.2f\n" +
                                            "  - Saldo actual: $%.2f\n",
                                    cantidadTransferir,
                                    numeroTransferir,
                                    saldoanterior,
                                    subcuentaEncontrada.getSaldo()
                            );

                            subcuentaEncontrada.setMovimientos(mensajeTransferencia, subcuentaEncontrada.getCont_movimientos());

                        }
                    } while (!transferenciaExitoso);
                } else {
                    System.out.println("Acceso denegado: PIN incorrecto");
                }
            }else {
                System.out.println("No se ha encontrado la cuenta o subcuenta!");
            }
        }else{
            System.out.println("No tienes un contacto registrado con ese nombre.");
        }
    }

    //Metodo para transferir dinero a alguien que no es contacto
    public void transferir(int idUsuario){

        System.out.println("\n꒰◌; Transferencia ");

        System.out.print("\n Ingrese el nombre: ");
        String nombre = scanner.nextLine();
        scanner.nextLine();

        String cuentaTransferencia;

        //\\d{13} → Permite exactamente 13 dígitos numéricos
        //\\d{16} → Permite exactamente 13 dígitos numéricos

        do {
            System.out.print("Ingrese el número de cuenta: ");
            cuentaTransferencia = scanner.nextLine();
            if (!cuentaTransferencia.matches("\\d{13}|\\d{16}")) {
                System.out.println("Número de cuenta inválido. Debe contener 13 o 16 dígitos y solo números.");
            }
        } while (!cuentaTransferencia.matches("\\d{13}|\\d{16}"));

        System.out.println("\n \n───────────");

        mostrarCuentas(idUsuario);


        System.out.println("\n Ingrese el número de cuenta de la que desea retirar: ");
        String numeroCuenta = validarSoloNumeros();

        Cuenta cuentaEncontrada = null;
        SubCuenta subcuentaEncontrada = null;

        for (Cuenta cuenta : cuentas) {
            if (numeroCuenta.equals(cuenta.getNumeroTarjeta()) && String.valueOf(idUsuario).equals(cuenta.getIdUsuario())) {
                cuentaEncontrada = cuenta;
                break;
            }
        }
        for (SubCuenta subcuenta : subCuentas) {
            if (numeroCuenta.equals(subcuenta.getSubNumeroTarjeta()) && String.valueOf(idUsuario).equals(subcuenta.getIdUsuario())) {
                subcuentaEncontrada = subcuenta;
                break;
            }
        }

        //si la transferencia es desdee una cuenta eje
        if (cuentaEncontrada != null) {
            System.out.println("Ingrese el NIP de la cuenta: ");
            String nip = validarSoloNumeros();

            if (cuentaEncontrada.getNip().equals(nip)) {
                System.out.println("Acceso permitido");

                boolean transferenciaExitoso = false;
                do {
                    double saldoActual = cuentaEncontrada.getSaldo();
                    System.out.println("Ingrese la cantidad a transferir: ");
                    double cantidadTransferir = scanner.nextDouble();

                    if (cantidadTransferir > cuentaEncontrada.getSaldo()) {
                        System.out.println("El saldo en la cuenta no es suficiente!");
                        System.out.println("Su saldo actual es de: $" + saldoActual);
                    } else if (cantidadTransferir < 0) {
                        System.out.println("Ingrese un número válido!");
                    } else {
                        Double saldoanterior = cuentaEncontrada.getSaldo();
                        cuentaEncontrada.setSaldo(saldoActual - cantidadTransferir);

                        //comprobar si no es una cuenta suya o de alguien del banco
                        comprobarCuentas(String.valueOf(idUsuario),cantidadTransferir,cuentaTransferencia);
                        transferenciaExitoso = true;

                        System.out.println("Transferencia exitosa! Nuevo saldo: $" + cuentaEncontrada.getSaldo());

                        String mensajeTransferencia = String.format(
                                " Transferencia realizada:\n" +
                                        "  - Cantidad transferida: $%.2f\n" +
                                        "  - Cuenta de destino: %s\n" +
                                        "  - Saldo anterior: $%.2f\n" +
                                        "  - Saldo actual: $%.2f\n",

                                cantidadTransferir,
                                cuentaTransferencia,
                                saldoanterior,
                                cuentaEncontrada.getSaldo()
                        );

                        cuentaEncontrada.setMovimientos(mensajeTransferencia, cuentaEncontrada.getCont_movimientos());
                    }
                } while (!transferenciaExitoso);
            } else {
                System.out.println("Acceso denegado: PIN incorrecto");
            }

          //si la transferencia es desde una subcuenta
        } else if(subcuentaEncontrada!=null){
            System.out.println("Ingrese el NIP de la cuenta: ");
            String nip = validarSoloNumeros();

            if (subcuentaEncontrada.getNip().equals(nip)) {
                System.out.println("Acceso permitido");

                boolean transferenciaExitoso = false;
                do {
                    double saldoActual = subcuentaEncontrada.getSaldo();
                    System.out.println("Ingrese la cantidad a transferir: ");
                    double cantidadTransferir = scanner.nextDouble();

                    if (cantidadTransferir > subcuentaEncontrada.getSaldo()) {
                        System.out.println("El saldo en la cuenta no es suficiente!");
                        System.out.println("Su saldo actual es de: $" + saldoActual);
                    } else if (cantidadTransferir < 0) {
                        System.out.println("Ingrese un número válido!");
                    } else {
                        Double saldoanterior = subcuentaEncontrada.getSaldo();
                        subcuentaEncontrada.setSaldo(saldoActual - cantidadTransferir);

                        //comprobar si no es una cuenta suya o de alguien del banco
                        comprobarCuentas(String.valueOf(idUsuario),cantidadTransferir,cuentaTransferencia);
                        transferenciaExitoso = true;

                        System.out.println("Transferencia exitosa! Nuevo saldo: $" + subcuentaEncontrada.getSaldo());

                        String mensajeTransferencia = String.format(
                                " Transferencia realizada:\n" +
                                        "  - Cantidad transferida: $%.2f\n" +
                                        "  - Cuenta de destino: %s\n" +
                                        "  - Saldo anterior: $%.2f\n" +
                                        "  - Saldo actual: $%.2f\n",
                                cantidadTransferir,
                                cuentaTransferencia,
                                saldoanterior,
                                subcuentaEncontrada.getSaldo()
                        );

                        subcuentaEncontrada.setMovimientos(mensajeTransferencia, subcuentaEncontrada.getCont_movimientos());
                    }
                } while (!transferenciaExitoso);
            } else {
                System.out.println("Acceso denegado: PIN incorrecto");
            }
        } else {
            System.out.println("No se ha encontrado la cuenta o subcuenta!");
        }
    }

    //Metodo para apagar o prender la tarjeta física
    public void estadoTarjeta(int id_Usuario){

        //recuperar información de la tarjeta
        for (Cuenta user : cuentas) {
            if (user.getIdUsuario().equals(String.valueOf(id_Usuario))) {

                String estado="";
                if(user.getEstado()){estado="Encendida";}
                else if(!user.getEstado()){estado="Apagada";}

                System.out.println("\n꒰◌; Estado de la tarjeta antes : "+ estado);

                //si la tarjeta está apagada prenderla
                if(!user.getEstado()){
                    user.setEstado(true);
                } else {
                    //si la tarjeta está prendida apagarla
                    user.setEstado(false);
                }

                if(user.getEstado()){estado="Encendida";}
                else if(!user.getEstado()){estado="Apagada";}

                System.out.println("\n꒰◌; Estado de la tarjeta actual : "+ estado);

            }
        }
    }

    //Metodo para que un usuario envíe un reporte
    public void enviarReporte(int id_usuario) {

        //recuperar numero de cuenta
        String numeroCuenta="";
        for (Cuenta cuenta : cuentas) {
            if (String.valueOf(id_usuario).equals(cuenta.getIdUsuario())) {
                numeroCuenta = cuenta.getNumeroTarjeta();
                break;
            }
        }

        System.out.println("\n꒰◌; Enviar reporte ");
        System.out.print("Ingrese la descripción del reporte: ");
        String descripcion = scanner.nextLine();

        // Crear el reporte con estado "Pendiente" (1)
        Reporte reporte = new Reporte(numeroCuenta, descripcion, 1);
        reportes.add(reporte);

        System.out.println("Reporte enviado exitosamente!");
    }

    //Metodo para que un usuario vea sus reportes
    public void verMisReportes(int id_usuario) {

        //recuperar numero de cuenta
        String numeroCuenta="";
        for (Cuenta cuenta : cuentas) {
            if (String.valueOf(id_usuario).equals(cuenta.getIdUsuario())) {
                numeroCuenta = cuenta.getNumeroTarjeta();
                break;
            }
        }

        System.out.println("\n꒰◌; Mis reportes ");
        boolean tieneReportes = false;

        for (Reporte reporte : reportes) {
            if (reporte.getNumeroCuenta().equals(numeroCuenta)) {
                System.out.println(reporte);
                tieneReportes = true;
            }
        }

        if (!tieneReportes) {
            System.out.println("No tienes reportes enviados.");
        }
    }

    //-------------------------------------------------------------------------

    //solicitudes

    //Metodo para que un usuario envíe una solicitud
    public void enviarSolicitud(String usuario, String numeroCuenta) {

        //Crear la solicitud con estado "Pendiente" (1)
        SolicitudInversion solicitud = new SolicitudInversion(numeroCuenta, usuario, "-------", 1);
        solicitudes.add(solicitud);
        System.out.println("Solicitud enviada exitosamente!");
    }

    //Metodo para que un subgerente vea sus solicitudes
    public void verMisSolicitudes(int id_usuario, int tipo_usuario) {

        String nombre="";
        //recuperar el nombre del usuario
       if(tipo_usuario==2){
            //subgerente
            for(SubGerente user:subgerentes){
                if(user.getIdSubgerente().equals(String.valueOf(id_usuario))){
                    nombre=user.getNombreUsuario();
                }
            }
        }else if(tipo_usuario==0){
            nombre="administrador";
        }

        System.out.println("\n--- Mis Solicitudes ---");
        boolean tieneSolicitudes = false;

        for (SolicitudInversion solicitud : solicitudes) {
            if (solicitud.getCuenta1().equals(nombre)) {
                System.out.println(solicitud);
                tieneSolicitudes = true;
            }
        }

        if (!tieneSolicitudes) {
            System.out.println("No tienes solicitudes enviadas.");
        }
    }

    //Metodo para que alguien vea todas las solicitudes pendientes
    public void verSolicitudesPendientes() {
        System.out.println("\n--- Solicitudes Pendientes ---");
        boolean haySolicitudesPendientes = false;

        for (SolicitudInversion solicitud : solicitudes) {
            if (solicitud.getEstado() == 1) { // Solo mostrar solicitudes pendientes
                System.out.println(solicitud);
                haySolicitudesPendientes = true;
            }
        }

        if (!haySolicitudesPendientes) {
            System.out.println("No hay solicitudes pendientes.");
        }
    }

    //Metodo para que un usuario (administrador o gerente) apruebe o rechace una solicitud
    public void cambiarEstadoSolicitud(int id_usuario, int tipo_usuario) {


        //recuperar el nombre del usuario
        String usuario="";
        if(tipo_usuario==0){
            usuario="administrador";
        }

        System.out.println("\n--- Gestionar Solicitud ---");
        System.out.println("Ingrese el número de cuenta de la solicitud: ");
        String numeroCuenta = scanner.nextLine();

        boolean solicitudEncontrada = false;
        for (SolicitudInversion solicitud : solicitudes) {
            if (solicitud.getNumeroCuenta().equals(numeroCuenta) && solicitud.getEstado() == 1) {
                System.out.println("Solicitud encontrada: " + solicitud);
                System.out.println("¿Desea aprobar la solicitud? (1 = Aprobar, 0 = Rechazar): ");
                int opcion = scanner.nextInt();

                if (opcion == 1) {
                    solicitud.setEstado(2); // Cambiar estado a "Aprobada"
                    solicitud.setCuenta2(usuario);
                    System.out.println("Solicitud aprobada exitosamente.");
                } else if (opcion == 0) {
                    solicitud.setEstado(0); // Cambiar estado a "Rechazada"
                    solicitud.setCuenta2(usuario);
                    System.out.println("Solicitud rechazada.");
                } else {
                    System.out.println("Opción no válida. No se realizaron cambios.");
                }

                solicitudEncontrada = true;
                break;
            }
        }

        if (!solicitudEncontrada) {
            System.out.println("No se encontró ninguna solicitud pendiente con ese número de cuenta.");
        }
    }

    //------------------------------------------------------------------------------

    //Movimientos del banco

    //metodo para listar todos los movimientos del banco
    public void listarMovimientos(){

        System.out.println("\n ─────────── Movimientos del banco ───────────");
        System.out.println("\n");

        if(cont_movimientos>1){
            for(int i=1; i<cont_movimientos;i++) {
                System.out.println((i) + ". " + movimientos[i]);
            }
        }else{
            System.out.println("No hay movimientos registrados en el banco.");
        }
        System.out.println("\n ───────────────────────────────────────────────────────");
    }

    //Metodo para ver los movimientos de una cuenta
    public void movimientosCuenta() {

        System.out.println("\n ─────────── Movimiento de una cuenta ───────────");
        System.out.println("\n");

        System.out.println(" \n ꒰◌; Ingresa el numero de tarjeta: ");
        System.out.println("\n");
        String numeroCuenta = scanner.nextLine();

        for (Cuenta cuenta : cuentas) {
            if (cuenta.getNumeroTarjeta().equals(numeroCuenta)) {
                String[] movimientos = cuenta.getMovimientos();
                if (cuenta.getCont_movimientos() != 0) {
                    for (int i = 0; i < movimientos.length; i++) {
                        if (movimientos[i] != null) {
                            System.out.println((i + 1) + ". " + movimientos[i]);
                        }
                    }
                } else {
                    System.out.println("No hay movimientos registrados.");
                }
                return;
            }
        }
        for (SubCuenta subcuenta : subCuentas) {
            if (subcuenta.getSubNumeroTarjeta().equals(numeroCuenta)) {
                String[] movimientos = subcuenta.getMovimientos();
                if (subcuenta.getCont_movimientos() != 0) {
                    for (int i = 0; i < movimientos.length; i++) {
                        if (movimientos[i] != null) {
                            System.out.println((i + 1) + ". " + movimientos[i]);
                        }
                    }
                } else {
                    System.out.println("No hay movimientos registrados.");
                }
                return;
            }
        }
        System.out.println("Cuenta no encontrada o no pertenece al usuario.");
    }
    
    
    
    //retornar todo lo de las listas
    
    public List<Cuenta> getCuentas() {
        return cuentas;
    }

    public List<SubCuenta> getSubCuentas() {
        return subCuentas;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }
    
    public List<SubGerente> getSubGerentes() {
        return subgerentes;
    }
    
     public List<Ventanilla> getCajeros() {
        return cajeros;
    }
    
    public List<SolicitudInversion> getSolicitudes(){
        return solicitudes;
    }
    
     public List<Contacto> getContactos(){
        return contactos;
    }
     
    public List<Reporte> getReportes(){
        return reportes;
    }
     
     //----------------------------
     
     
    public int[] getContadores() {
        return contadores;
    }
    
    public int getCont_Movimientos(){
        return cont_movimientos;
    }
    
    public String[] getMovimientos() {
        return movimientos;
    }
    
    public void setMovimientos(String movimiento,int cont_movimientos){
        this.movimientos[cont_movimientos] = movimiento;
        this.cont_movimientos = cont_movimientos+1;
    }
    
    public double getSaldoBanco(){
        return saldoInicial;
    }
    
    public void setSaldoBanco(double saldoBanco){
        this.saldoInicial = saldoBanco;
    }
    
    public double getSaldoCajero(){
        return saldoCajero;
    }
    
    public void setSaldoCajero(double saldoCajero){
        this.saldoCajero= saldoCajero;
    }
    
    
}

