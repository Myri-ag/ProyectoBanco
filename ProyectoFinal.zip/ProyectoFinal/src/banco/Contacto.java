/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package banco;

/**
 *
 * @author eliag
 */
public class Contacto {
    private String idUsuario;      // [0] ID del usuario que tiene los contactos (FK)
    private String Nombre;         // [1] Nombre con el que el usuario guardó al contacto
    private String numeroCuenta;   // [2] Numero de cuenta del contacto


    // Constructor
    public Contacto(String idUsuario, String Nombre, String numeroCuenta) {
        this.idUsuario = idUsuario;
        this.Nombre = Nombre;
        this.numeroCuenta = numeroCuenta;
    }

    // Getters y Setters
    public String getIdUsuario() {
        return idUsuario;
    }

    public String getNombre() {
        return Nombre;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

}